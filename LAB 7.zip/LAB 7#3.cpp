#include<stdio.h>
int main()
{
	float temp[7][4];
	char slots[4][10]={"morning","noon","evening","night"};
	int i;
	int j;
	int hot_day=0;
	int hot_slot=0;
	int cold_day=0;
	int cold_slot=0;
	float hottest=0;
	float coldest=0;
	float noon_sum=0;
	float noon_average=0;
	for(i=0;i<7;i++)
	{
		for(j=0;j<4;j++)
		{
			printf("Enter temperature of day %d %s\n",i+1,slots[j]);
			scanf("%f",&temp[i][j]);
		}
	}
	hottest=temp[0][0];
	coldest=temp[0][0];
	for(i=0;i<7;i++)
	{
		for(j=0;j<4;j++)
		{
			if(temp[i][j]>hottest)
			{
				hottest=temp[i][j];
				hot_day=i;
				hot_slot=j;
			}
			if(temp[i][j]<coldest)
			{
				coldest=temp[i][j];
				cold_day=i;
				cold_slot=j;
			}
		}
		noon_sum=noon_sum+temp[i][1];
	}
	noon_average=noon_sum/7.0;
	printf("Hottest=%.2f on day %d (%s)\n",hottest,hot_day+1,slots[hot_slot]);
	printf("Coldest=%.2f on day %d (%s)\n",coldest,cold_day+1,slots[cold_slot]);
	printf("Days with noon above average (%.2f):",noon_average);
	for(i=0;i<7;i++)
	{
		if(temp[i][1]>noon_average)
		{
			printf(" %d",i+1);
		}
	}
	printf("\n");
	return 0;
}
