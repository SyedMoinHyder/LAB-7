#include<stdio.h>
int main()
{
	char rows[3][3];
	int i;
	int j;
	printf("Game is Started(Enter (X),(O) OR(-))Choice is your Slect any two\n");
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			scanf(" %c",&rows[i][j]);
			if(rows[i][j]!='X'&&rows[i][j]!='O'&&rows[i][j]!='-')
			{
				printf("Invalid input\n");
				return 1;
		}
		
			}
	}
			if(rows[0][0]==rows[0][1]&&rows[0][0]==rows[0][2]&&rows[0][0]!='-')
			{
				printf("Winner %c",rows[0][0]);
			}
			else if(rows[1][0]==rows[1][1]&&rows[1][0]==rows[1][2]&&rows[1][0]!='-')
			{
				printf("Winner %c",rows[1][0]);
			}
				else if(rows[2][0]==rows[2][1]&&rows[2][0]==rows[2][2]&&rows[2][0]!='-')
			{
				printf("Winner %c",rows[2][0]);
			}
				else if(rows[0][0]==rows[1][0]&&rows[0][0]==rows[2][0]&&rows[0][0]!='-')
			{
				printf("Winner %c",rows[0][0]);
			}
				else if(rows[0][1]==rows[1][1]&&rows[0][1]==rows[2][1]&&rows[0][1]!='-')
			{
				printf("Winner %c",rows[0][1]);
			}
				else if(rows[0][2]==rows[1][2]&&rows[0][2]==rows[2][2]&&rows[0][2]!='-')
			{
				printf("Winner %c",rows[0][2]);
			}
			else if(rows[2][0]==rows[1][1]&&rows[2][0]==rows[0][2]&&rows[2][0]!='-')
			{
				printf("Winner %c",rows[0][0]);
			}
			else if(rows[0][0]==rows[1][1]&&rows[0][0]==rows[2][2]&&rows[0][0]!='-')
			{
				printf("Winner %c",rows[0][0]);
			}
			else
			{
				printf("draw");
			}
	return 0;
	
}
