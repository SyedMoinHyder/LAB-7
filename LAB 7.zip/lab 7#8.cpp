#include<stdio.h>
int main()
{
	int stock[3][4][5];
	int b;
	int s;
	int j;
	int total=0;
	int shelf_total=0;
	int max_shelf=0;
	int max_b=0;
	int max_s=0;
	for(b=0;b<3;b++)
	{
		for(s=0,total=0;s<4;s++)
		{
			for(j=0,shelf_total=0;j<5;j++)
			{
				printf("Enter stock of building %d shelf %d slot %d\n",b+1,s+1,j+1);
				scanf("%d",&stock[b][s][j]);
				shelf_total=shelf_total+stock[b][s][j];
				if(stock[b][s][j]<5)
				{
					printf("needs restock at [%d][%d][%d]\n",b+1,s+1,j+1);
				}
			}
			total=total+shelf_total;
			if(shelf_total>max_shelf)
			{
				max_shelf=shelf_total;
				max_b=b+1;
				max_s=s+1;
			}
		}
		printf("Total stock of building %d=%d\n",b+1,total);
	}
	printf("Fullest shelf is building %d shelf %d with %d items\n",max_b,max_s,max_shelf);
	return 0;
}
