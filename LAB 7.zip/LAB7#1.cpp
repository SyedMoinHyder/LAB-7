#include<stdio.h>
int main()
{
	int seats[5][8];
	int i;
	int j;
	int free_row=0;
	int total_free=0;
	for(i=0;i<5;i++)
	{
		for(j=0;j<8;j++)
		{
			printf("Enter status of row %d seat %d (0=empty, 1=booked)\n",i+1,j+1);
			scanf("%d",&seats[i][j]);
		}
	}
	printf("\nSeating Map\n");
	for(i=0;i<5;i++)
	{
		for(j=0,free_row=0;j<8;j++)
		{
			if(seats[i][j]==0)
			{
				printf(". ");
				free_row=free_row+1;
			}
			else
			{
				printf("X ");
			}
		}
		total_free=total_free+free_row;
		printf("  Free seats in row %d=%d\n",i+1,free_row);
	}
	printf("Total free seats=%d\n",total_free);
	return 0;
}
0
