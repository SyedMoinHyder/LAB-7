#include<stdio.h>
int main()
{
	int rooms[4][6];
	int i;
	int j;
	int vacant=0;
	int max_vacant=-1;
	int max_floor=0;
	int count=0;
	int found=0;
	for(i=0;i<4;i++)
	{
		for(j=0;j<6;j++)
		{
			printf("Enter status of floor %d room %d (1=occupied, 0=vacant)\n",i+1,j+1);
			scanf("%d",&rooms[i][j]);
		}
	}
	for(i=0;i<4;i++)
	{
		for(j=0,vacant=0;j<6;j++)
		{
			if(rooms[i][j]==0)
			{
				vacant=vacant+1;
			}
		}
		if(vacant>max_vacant)
		{
			max_vacant=vacant;
			max_floor=i+1;
		}
	}
	printf("Floor with most vacancies=%d (%d rooms)\n",max_floor,max_vacant);
	for(i=0;i<4;i++)
	{
		for(j=0,count=0;j<6;j++)
		{
			if(rooms[i][j]==0)
			{
				count=count+1;
			}
			else
			{
				count=0;
			}
			if(count==3)
			{
				printf("3 or more consecutive vacant rooms on floor %d starting at room %d\n",i+1,j-1);
				found=1;
			}
		}
	}
	if(found==0)
	{
		printf("No floor has 3 or more consecutive vacant rooms\n");
	}
	return 0;
}
