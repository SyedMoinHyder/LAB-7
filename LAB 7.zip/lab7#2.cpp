#include<stdio.h>
int main()
{
	int marks[6][4];
	int i;
	int m;
	int o;
	int total=0;
	int total_class_marks=0;
	float avg=0;
	float class_avg_sub=0;
	float bst_avg=0;
	for(i=0;i<6;i++)
	{
		for(m=0,total=0,avg=0;m<4;m++)
        {
           scanf("%d",&marks[i][m]);
           total=total+marks[i][m];
		}
		printf("Total marks=%d\n",total);
		avg=total/4.0;
		printf("total average=%.2f\n",avg);
	}
	for(m=0,bst_avg=0;m<4;m++)
	{
		for(i=0,total_class_marks=0,class_avg_sub=0;i<6;i++)
		{
			total_class_marks=total_class_marks+marks[i][m];
		}
	     class_avg_sub=total_class_marks/6.0;
	     printf("Class Average of subject %d =%.2f\n",m+1,class_avg_sub);
	     if(class_avg_sub>bst_avg)
	     o=o+1;
	}
	printf("Subject where class performed best=%d",o);
	return 0;
}
