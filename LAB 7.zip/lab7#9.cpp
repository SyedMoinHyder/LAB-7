#include<stdio.h>
int main()
{
	char titles[5][50];
	int copies[5];
	int vowels[5];
	int i;
	int j;
	int found=0;
	int max_vowels=0;
	int max_index=0;
	char letter;
	for(i=0;i<5;i++)
	{
		printf("Enter title of book %d\n",i+1);
		scanf(" %[^\n]",titles[i]);
		printf("Enter number of copies\n");
		scanf("%d",&copies[i]);
	}
	printf("\n%-5s %-30s %s\n","No.","Title","Copies");
	for(i=0;i<5;i++)
	{
		printf("%-5d %-30s %d\n",i+1,titles[i],copies[i]);
	}
	for(i=0;i<5;i++)
	{
		vowels[i]=0;
		for(j=0;titles[i][j]!='\0';j++)
		{
			if(titles[i][j]=='a'||titles[i][j]=='e'||titles[i][j]=='i'||titles[i][j]=='o'||titles[i][j]=='u'||titles[i][j]=='A'||titles[i][j]=='E'||titles[i][j]=='I'||titles[i][j]=='O'||titles[i][j]=='U')
			{
				vowels[i]=vowels[i]+1;
			}
		}
		printf("Vowels in %s = %d\n",titles[i],vowels[i]);
		if(vowels[i]>max_vowels)
		{
			max_vowels=vowels[i];
			max_index=i;
		}
	}
	printf("Enter a letter\n");
	scanf(" %c",&letter);
	for(i=0;i<5;i++)
	{
		if(titles[i][0]==letter||titles[i][0]==letter-32||titles[i][0]==letter+32)
		{
			printf("%s\n",titles[i]);
			found=1;
		}
	}
	if(found==0)
	{
		printf("No title starts with %c\n",letter);
	}
	printf("Title with most vowels is %s (%d)\n",titles[max_index],max_vowels);
	return 0;
}
