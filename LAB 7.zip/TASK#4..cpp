#include<stdio.h>
int main()
{
	int units;
	char connection_type;
	int bill;
	printf("**Welcome To Electricity Bill Calculator**\n\n");
	printf("Enter units consumed :\n");
	scanf("%d",&units);
	printf("Enter Connection type :\n");
	printf("Enter C for commercial \n");
	printf("Enter D for domestic   \n");
	scanf(" %c",&connection_type);
	if (connection_type=='C'||connection_type=='c')
	{
		if(units>=0&&units<=100)
		{
		bill=350;
	    }
	    else if (units>=101&&units<=300)
	    {
	    	bill=1000;
		}
		else if(units>300)
		{
			bill=units*10;
		}
	}
	else if(connection_type=='D'||connection_type=='d')
	{
		if(units>=0&&units<=100)
		{
		bill=450;
	    }
	    else if (units>=101&&units<=300)
	    {
	    	bill=2000;
		}
		else if(units>300)
		{
			bill=units*15;
		}
		
	}
	printf("Your bill is %d: ",bill);
	return 0;
	
}
