#include<stdio.h>
int main()
{
	int marks [3][4][5];
	int m;
	int j;
	int i;
	int sum=0;
	int n;
	int z;
	float average=0;
	float highest_average=0;
	float dept_sum=0;
	float dept_average=0;
	float best_dept_average=0;
	int best_dept=0;
	for(m=0;m<3;m++)
	{
		for(i=0,highest_average=0,n=0,dept_sum=0;i<4;i++)
		{
			for(j=0,sum=0,z=0;j<5;j++)
			{
				printf("Enter your marks\n");
				scanf("%d",&marks[m][i][j]);
				if(marks[m][i][j]<40)
				{
					z=z+1;
				}
				sum=sum+marks[m][i][j];
			}
			average=sum/5.0;
			printf("student %d Average is=%.2f ",i+1,average);
			if(z>0)
			{
				printf("FAIL");
			}
			printf("\n");
			dept_sum=dept_sum+average;
			if(average>highest_average)
			{
				highest_average=average;
				n=i+1;
			}
		}
		dept_average=dept_sum/4;
		if(dept_average>best_dept_average)
		{
			best_dept_average=dept_average;
			best_dept=m+1;
		}
		printf("Topper of class is student=%d\n",n);
	}
	printf("Department with highest overall average=%d (%.2f)\n",best_dept,best_dept_average);
	return 0;
}
